// Import required modules
const cors = require("cors"); // Middleware for enabling Cross-Origin Resource Sharing
const express = require("express"); // Build Node.js web framework
const bodyParser = require("body-parser"); // The module used to solve the body of the incoming request
const path = require("path"); //  a Module for working with file and directory paths

// Create an instance of the Express application
const app = express();

//  setting
app.use(bodyParser.urlencoded({ extended: true })); 
app.use(bodyParser.json()); // Parses JSON bodies
app.use(cors()); // CORS can  be fully used
app.use(express.static(__dirname)); // Serve static files from the current directory

// Route to serve the main HTML page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html")); // Send the  file
});


app.get("/SearchFundraiser", (req, res) => {
  res.sendFile(path.join(__dirname, "SearchFundraiser.html")); 
});

app.get("/Fundraiser", (req, res) => {
  res.sendFile(path.join(__dirname, "Fundraiser.html")); 
});

app.listen(8080, () => {
  console.log("Server is running on port 8080"); // Log a message to the console
});

